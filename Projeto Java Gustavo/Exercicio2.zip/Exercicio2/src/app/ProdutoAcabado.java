
package app;

public class ProdutoAcabado extends Produto {
   private float montagem;
   private String pintura;
   private float preco;

    public float getMontagem() {
        return montagem;
    }

    public void setMontagem(float montagem) {
        this.montagem = montagem;
    }

    public String getPintura() {
        return pintura;
    }

    public void setPintura(String pintura) {
        this.pintura = pintura;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }


   
   
}

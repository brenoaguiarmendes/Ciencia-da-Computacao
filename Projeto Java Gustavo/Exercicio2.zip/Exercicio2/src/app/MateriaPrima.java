
package app;

public class MateriaPrima extends Produto{
    
    private String quadro;
    private String pneuearo;
    private String corrente;
    private String guidao;
    private String freio;

    public String getQuadro() {
        return quadro;
    }

    public void setQuadro(String quadro) {
        this.quadro = quadro;
    }

    public String getPneuearo() {
        return pneuearo;
    }

    public void setPneuearo(String pneuearo) {
        this.pneuearo = pneuearo;
    }

    
    public String getCorrente() {
        return corrente;
    }

    public void setCorrente(String corrente) {
        this.corrente = corrente;
    }

    public String getGuidao() {
        return guidao;
    }

    public void setGuidao(String guidao) {
        this.guidao = guidao;
    }

    public String getFreio() {
        return freio;
    }

    public void setFreio(String freio) {
        this.freio = freio;
    }

    
    
}

